package com.is.tieto_visa.tieto;

public class ConfirmRefillFilter extends ConfirmRefill {

}
