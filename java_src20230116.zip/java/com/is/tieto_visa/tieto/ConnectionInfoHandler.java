package com.is.tieto_visa.tieto;

public interface ConnectionInfoHandler {	
	
	WSConnectionInfo getWSConnectionInfo();
	
}