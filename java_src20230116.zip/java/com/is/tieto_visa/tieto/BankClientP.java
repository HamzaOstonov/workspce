package com.is.tieto_visa.tieto;

import java.util.Date;


public class BankClientP {
	
	
    private String branch;
	
	
    private String id;
	
	
    private String name;
	
	
    private Date birthday;
	
	
    private String post_address;
	
	
    private String passport_type;
	
	
    private String passport_serial;
	
	
    private String passport_number;
	
	
    private String passport_place_registration;
	
	
    private Date passport_date_registration;
	
	
    private String code_place_regist;
	
	
    private Date date_registration;
	
	
    private String number_registration_doc;
	
	
    private String code_tax_org;
	
	
    private String number_tax_registration;
	
	
    private String code_sector;
	
	
    private String code_organ_direct;
	
	
    private String code_bank;
	
	
    private String account;
	
	
    private String code_class_credit;
	
	
    private Long state;
	
	
    private Long kod_err;
	
	
    private String file_name;
	
	
    private String code_citizenship;
	
	
    private String birth_place;
	
	
    private String code_capacity;
	
	
    private Date capacity_status_date;
	
	
    private String capacity_status_place;
	
	
    private String num_certif_capacity;
	
	
    private String phone_home;
	
	
    private String phone_mobile;
	
	
    private String email_address;
	
	
    private String pension_sertif_serial;
	
	
    private String code_gender;
	
	
    private String code_nation;
	
	
    private String code_birth_region;
	
	
    private String code_birth_distr;
	
	
    private String type_document;
	
	
    private Date passport_date_expiration;
	
	
    private String code_adr_region;
	
	
    private String code_adr_distr;
	
	
    private String inps;
	
	
    private String family;
	
	
    private String first_name;
	
	
    private String patronymic;
	
	
    private String sign_vip;
}
