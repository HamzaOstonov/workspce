package com.is.tieto_visa.tieto;

import java.util.Date;

public class BankClient {
	
	
    private Long id;
	
	
    private String branch;
	
	
    private String id_client;
	
	
    private String name;
	
	
    private String code_country;
	
	
    private String code_type;
	
	
    private String code_resident;
	
	
    private String code_subject;
	
	
    private String code_form;
	
	
    private Date date_open;
	
	
    private Date date_close;
	
	
    private Double state;
	
	
    private Double kod_err;
	
	
    private String file_name;
	
	
    private int sign_registr;
}
