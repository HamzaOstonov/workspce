package com.is.tieto_visa.tieto;

import org.zkoss.zul.impl.InputElement;

public interface InputElHandler {
	void makeChanges(InputElement element);
}
