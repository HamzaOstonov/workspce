package com.is.tieto_visa.tieto;


public class ResponseInfoHolder  {
	public ResponseInfo value;

	public ResponseInfoHolder(ResponseInfo value) {
		super();
		this.value = value;
	}

	public ResponseInfoHolder() {
		super();
	}
}
