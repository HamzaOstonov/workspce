package com.is.tieto_visa.customer;

import com.is.tieto_visa.tieto.AccInfo;
import com.is.tieto_visa.tieto.CardInf;

public class ConfirmationRepData
{
	public AccInfo acc;
	public CardInf cardInfo;
}
