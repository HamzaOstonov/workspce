package com.is.openway;


public class Person {
   
	  private int x = 1;
	    private int y = 2;
	    
	private String _id;

    private String name;

 


	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String get_id() {
		return _id;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getX() {
		return x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getY() {
		return y;
	}
}
