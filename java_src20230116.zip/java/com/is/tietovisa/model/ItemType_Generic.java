/**
 * ItemType_Generic.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.is.tietovisa.model;


public class ItemType_Generic {
    private java.lang.String name;

    private java.lang.String value;

    public ItemType_Generic() {
    }

    public ItemType_Generic(
           java.lang.String name,
           java.lang.String value) {
           this.name = name;
           this.value = value;
    }


    /**
     * Gets the name value for this ItemType_Generic.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this ItemType_Generic.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the value value for this ItemType_Generic.
     * 
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }


    /**
     * Sets the value value for this ItemType_Generic.
     * 
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }


}
