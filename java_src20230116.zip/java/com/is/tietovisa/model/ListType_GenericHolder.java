/**
 * ListType_GenericHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.is.tietovisa.model;


public final class ListType_GenericHolder implements javax.xml.rpc.holders.Holder {
    public ItemType_Generic[][] value;

    public ListType_GenericHolder() {
    }

    public ListType_GenericHolder(ItemType_Generic[][] value) {
        this.value = value;
    }

}
